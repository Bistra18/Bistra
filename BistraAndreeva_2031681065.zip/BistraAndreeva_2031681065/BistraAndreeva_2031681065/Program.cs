﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BistraAndreeva_2031681065.Program;

namespace BistraAndreeva_2031681065
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Knight knight = new Knight("Sir John", new Spear());
            Rogue rogue = new Rogue("Rogue", new Dagger());
            Ninja ninja = new Ninja("Ninja", new Shuriken());
            Cowboy cowboy = new Cowboy("Cowboy", new Lasso());

            // Създаване на арена и добавяне на героите
            Arena arena = new Arena(knight, rogue);
            arena.AddHero(ninja);
            arena.AddHero(cowboy);

            // Извикване на метода за битка
            Hero winner = arena.Battle();

            // Извеждане на победителя
            Console.WriteLine("Победител: " + winner.Name);
        }
        public class Arena
        {
            private List<Hero> heroes = new List<Hero>();
            private static readonly Random random = new Random();

            public void AddHero(Hero hero)
            {
                heroes.Add(hero);
            }

            public Hero HeroA { get; private set; }
            public Hero HeroB { get; private set; }

            public Arena(Hero a, Hero b)
            {
                HeroA = a;
                HeroB = b;
            }

            public Hero Battle()
            {
                Hero attacker, defender;
                if (random.Next(2) == 0)
                {
                    attacker = HeroA;
                    defender = HeroB;
                }
                else
                {
                    attacker = HeroB;
                    defender = HeroA;
                }
                while (true)
                {
                    int damage = attacker.Attack();
                    defender.TakeDamage(damage);
                    if (defender.IsDead) return attacker;
                    // Swap the heroes
                    Hero tmp = attacker;
                    attacker = defender;
                    defender = tmp;
                }
            }
        }

        public class Hero
        {
            protected static readonly Random random = new Random();

            public string Name { get; private set; }
            public int Health { get; private set; }
            public int Strength { get; private set; }
            protected int StartingHealth { get; private set; }
            public bool IsDead { get { return Health <= 0; } }
            protected Weapon Weapon { get; set; }

            public Hero(string name, Weapon weapon)
            {
                Name = name;
                Health = 500;
                StartingHealth = Health;
                Strength = 100;
                Weapon = weapon;
            }

            public virtual int Attack()
            {
                return Weapon.ModifyAttack((Strength * random.Next(80, 121)) / 100);
            }

            public virtual void TakeDamage(int incomingDamage)
            {
                if (incomingDamage < 0) return;
                Health -= incomingDamage;
            }

            protected bool ThrowDice(int chance)
            {
                int dice = random.Next(101);
                return dice <= chance;
            }

            protected void Heal(int value)
            {
                Health += value;
                if (Health > StartingHealth) Health = StartingHealth;
            }
        }

        public class Knight : Hero
        {
            private const int BlockDamageChance = 10;
            private const int ExtraDamageChance = 5;

            public Knight() : this("Sir John", new Spear()) { }

            public Knight(string name, Weapon weapon) : base(name, weapon) { }

            public override void TakeDamage(int incomingDamage)
            {
                // Apply armor
                int damageReduceCoef = random.Next(20, 61);
                incomingDamage -= (incomingDamage * damageReduceCoef) / 100;
                // Apply special skill: block
                if (ThrowDice(BlockDamageChance)) incomingDamage = 0;
                // Default behavior
                base.TakeDamage(incomingDamage);
            }

            public override int Attack()
            {
                int attack = base.Attack();
                if (ThrowDice(ExtraDamageChance)) attack = attack * 150 / 100;
                return attack;
            }
        }

        public class Rogue : Hero
        {
            private const int TripleDamageMagicLastDigit = 5;
            private const int HealEachNthRound = 3;
            private int attackCount;

            public Rogue() : this("Rogue", new Dagger()) { }

            public Rogue(string name, Weapon weapon) : base(name, weapon)
            {
                attackCount = 0;
            }

            public override int Attack()
            {
                int attack = base.Attack();
                if (attack % 25 == TripleDamageMagicLastDigit)
                {
                    attack = attack * 3;
                }
                attackCount++;
                if (attackCount % HealEachNthRound == 0 && ThrowDice(25))
                {
                    Heal(StartingHealth * 50 / 100);
                }
                return attack;
            }

            public override void TakeDamage(int incomingDamage)
            {
                if (ThrowDice(30)) incomingDamage = 0;
                base.TakeDamage(incomingDamage);
            }
        }

        public class Ninja : Hero
        {
            private const int ExtraShurikenDamageChance = 10;

            public Ninja() : this("Ninja", new Shuriken()) { }

            public Ninja(string name, Weapon weapon) : base(name, weapon) { }

            public override int Attack()
            {
                int attack = base.Attack();
                if (ThrowDice(ExtraShurikenDamageChance))
                {
                    attack = attack * 2; // Double damage with shuriken
                }
                return attack;
            }

            public override void TakeDamage(int incomingDamage)
            {
                base.TakeDamage(incomingDamage);
            }
        }

        public class Cowboy : Hero
        {
            private const int LassoStunChance = 15;

            public Cowboy() : this("Cowboy", new Lasso()) { }

            public Cowboy(string name, Weapon weapon) : base(name, weapon) { }

            public override int Attack()
            {
                int attack = base.Attack();
                if (ThrowDice(LassoStunChance))
                {
                    attack += 50; // Extra damage with lasso
                }
                return attack;
            }

            public override void TakeDamage(int incomingDamage)
            {
                base.TakeDamage(incomingDamage);
            }
        }

        public abstract class Weapon
        {
            protected static readonly Random random = new Random();

            public abstract int ModifyAttack(int baseAttack);
        }

        public class Spear : Weapon
        {
            private const int PierceChance = 20;

            public override int ModifyAttack(int baseAttack)
            {
                if (random.Next(100) < PierceChance)
                {
                    return baseAttack * 2; // Double damage for piercing hit
                }
                return baseAttack;
            }
        }

        public class Dagger : Weapon
        {
            private const int TripleHitChance = 5;

            public override int ModifyAttack(int baseAttack)
            {
                if (random.Next(100) < TripleHitChance)
                {
                    return baseAttack * 3; // Triple hit triples the attack
                }
                return baseAttack;
            }
        }

        public class Shuriken : Weapon
        {
            private const int ExtraDamageChance = 10;

            public override int ModifyAttack(int baseAttack)
            {
                if (random.Next(100) < ExtraDamageChance)
                {
                    return baseAttack * 2; // Double damage with shuriken
                }
                return baseAttack;
            }
        }

        public class Lasso : Weapon
        {
            private const int ExtraDamageChance = 15;

            public override int ModifyAttack(int baseAttack)
            {
                if (random.Next(100) < ExtraDamageChance)
                {
                    return baseAttack + 50; // Extra damage with lasso
                }
                return baseAttack;
            }
        }
    }
}
